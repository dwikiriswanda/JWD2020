Menghitung IPK
====================
|stable v1.0| |downloads 312| |license MIT| 

PRogram ini dibuat untuk memudahkan urusan mahasiswa dalam menghitung IPK akhir mereka

Install peralatan yang dibutuhkan, dan kemudian jalankan programnya


Requirements
============

* Browser
* Text Editor
* Web Server


Installation
============

- Install Requirements yang dibutuhkan jika di perangkat anda belum ada
- Ikuti langkah instalasi sampai selesai
- Setelah selesai tinggal jalankan program dengan mengikuti konfigurasi


Configuration
=============

- Copy file php ke dalam C:/xampp/htdocs/
- Start Xampp Control Panel, dan jalankan modul Apache
- Buka browser dan ketik "localhost/nama_file.php" pada URL


Usage
=====

Masukkan jumlah Mata Kuliah, kemudian klik tombol Submit. Setelah itu masukkan data mata kuliah yang berhubungan (nama Mata Kuliah, Nilai, jumlah SKS) lalu tekan Submit


Features
========

- Menampilkan Grade
- Menampilkan Bobot Grade
- Menampilkan IPK Akhir Mahasiswa


Credits
=======

* Muhamad Dwiki Riswanda as Developer
* Fiddo Hafied Rum as Asesor


License
=======

Licensed under The MIT License