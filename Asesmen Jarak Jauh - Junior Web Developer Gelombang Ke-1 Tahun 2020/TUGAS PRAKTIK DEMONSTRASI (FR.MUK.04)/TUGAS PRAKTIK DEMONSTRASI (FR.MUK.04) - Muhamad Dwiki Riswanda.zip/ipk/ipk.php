<?php
    $matkul= $_GET['txtmatkul'];
    $SKS=$_GET['txtSKS'];
    $Nilai=$_GET['txtNilai'];

    echo "<table border='2'>";
    echo "
        <tr>
            <td>NAMA MATAKULIAH</td>
            <td>NILAI</td>
            <td>GRADE</td>
            <td>BOBOT GRADE</td>
            <td>SKS</td>
        </tr>";

    // menampilkan array kedalam table
    foreach ($matkul as $key => $namaMatkul) { 

        // convert Nilai ke Grade
        if ($Nilai[$key] > 85 && $Nilai[$key] <= 100) { 
            $Grade="A";
        } else if ($Nilai[$key] > 75 && $Nilai[$key] <= 85) {
            $Grade="B";          
        } else if ($Nilai[$key] > 65 && $Nilai[$key] <= 75) {
            $Grade="C";        
        } else if ($Nilai[$key] > 55 && $Nilai[$key] <= 65) {
            $Grade="D";        
        } else{
            $Grade="E";
        }

        // convert Nilai ke Bobot Grade
        if ($Nilai[$key] > 85 && $Nilai[$key] <= 100) { 
            $bobotGrade=4;
        } else if ($Nilai[$key] > 75 && $Nilai[$key] <= 85) {
            $bobotGrade=3;          
        } else if ($Nilai[$key] > 65 && $Nilai[$key] <= 75) {
            $bobotGrade=2;        
        } else if ($Nilai[$key] > 55 && $Nilai[$key] <= 65) {
            $bobotGrade=1;        
        } else{
            $bobotGrade=0;
        }

        echo "
        <tr>
            <td>$namaMatkul</td>
            <td>$Nilai[$key]</td>
            <td>$Grade</td>
            <td>$bobotGrade</td>
            <td>$SKS[$key]</td>
        </tr>";
    }

    echo "</table>";


    $bobotGrade=array();
    // menentukan bobotGrade nilai untuk dimasukkan ke Array
    foreach ($Nilai as $nilaiMatkul) { 
        if ($nilaiMatkul > 85 && $nilaiMatkul <= 100) {
            $bobotGrade[]=4;
        } else if ($nilaiMatkul > 75 && $nilaiMatkul <= 85) {
            $bobotGrade[]=3;          
        } else if ($nilaiMatkul > 65 && $nilaiMatkul <= 75) {
            $bobotGrade[]=2;        
        } else if ($nilaiMatkul > 55 && $nilaiMatkul <= 65) {
            $bobotGrade[]=1;        
        } else{
            $bobotGrade[]=0;
        }
    }  

    $ip=array();
    $ipSementara=array();

    // menghitung ip Sementara yaitu dengan Bobot Grade x SKS
    foreach ($SKS as $key => $jumlahSKS) {  
        $ip[$key] = $bobotGrade[$key] * $jumlahSKS ; 
        $ipSementara[] = $ip[$key];
    }

    // Hasil akhir yaitu Jumlah(Bobot Grade x SKS)/Total SKS
    $ipkAkhir= array_sum($ipSementara) / array_sum($SKS);  
    echo "IPK akhir anda adalah :"  .$ipkAkhir;

?>