<?php
    $jmlhmk =$_GET['txtjmlh'];  
    for ($i=1; $i <= $jmlhmk; $i++) {

        echo "<form action ='ipk.php' type='get'>";
        echo "<table width ='75%' table border='1'>";
        
        echo "<tr>.$i
            </br>
            <td> Nama Mata Kuliah :</td> <td> <input type='text'name='txtmatkul[]'/> </td>
            <td> NILAI :</td><td> <input type='number'name='txtNilai[]'/> </td>
            <td> SKS :</td><td> <input type='text'name='txtSKS[]'/> </td>
            </tr>";
        echo "</table>";
    }

        echo "<input type='submit' name='submit' value='submit'/>";  
        echo "</form>" ;

?>